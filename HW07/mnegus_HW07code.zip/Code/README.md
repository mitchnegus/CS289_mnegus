README
==============================================================================================
Mitch Negus
3032146443
---------------------------------------------------------------------------------------------------------------------------------------------------------------------
CODE - HW07 - CompSci 289A

The code for this assignment includes the following files:

* HW07_utils.py					-utility module with functions to load & format data files
* CS289A_HW07_prob1.ipynb			-notebook containing problem 1
* CS289A_HW07_prob2.ipynb			-notebook containing problem 2

*the .py module must be in the PYTHONPATH for the problem 7 notebooks to work properly.

Jupyter notebooks contain additional internal documentation describing their procedures.
